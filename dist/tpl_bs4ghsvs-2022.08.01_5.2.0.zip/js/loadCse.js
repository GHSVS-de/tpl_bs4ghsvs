// Google Custom Search Engine for ghsvs.de
var loadCse = function() {
	var cx = '013374206557569939775:ywhspwocw9o';
	var gcse = document.createElement('script');
	gcse.type = 'text/javascript';
	gcse.async = true;
	gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
	var s = document.getElementsByTagName('script')[0];
	s.parentNode.insertBefore(gcse, s);
};